﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

enum BLOCKDIR
{
    BD_T,
    BD_R,
    BD_B,
    BD_L,
    BD_MAX
}

enum BLOCKTYPE
{
    BT_I,
    BT_L,
    BT_J, 
    BT_Z, 
    BT_S, 
    BT_T, 
    BT_O,
    BT_MAX
}

partial class Block
{
    int X = 0;
    int Y = 0;
    int Wait = 0;

    BLOCKDIR Dir = BLOCKDIR.BD_T;
    string[][] Arr = null;
   // List<List<string>> BlockData = new List<List<string>>();

    BLOCKTYPE CurBlockType = BLOCKTYPE.BT_T;
    BLOCKDIR CurDirType = BLOCKDIR.BD_T;

    TETRISSCREEN Screen = null;
    AccScreen AccScreen = null;
    Random NewRandom = new Random();

    public Block(TETRISSCREEN _Screen, AccScreen _AccScreen)
    {
        if(_Screen == null || _AccScreen == null)
        {
            return;
        }    

        Screen = _Screen;
        AccScreen = _AccScreen;
        DataInit();

        Reset();
    }

    public void RandomBlockType()
    {
        int RandomIndex = NewRandom.Next((int)BLOCKTYPE.BT_I, (int)BLOCKTYPE.BT_MAX);
        CurBlockType = (BLOCKTYPE)RandomIndex;
    }

    private void SettingBlock(BLOCKTYPE _Type, BLOCKDIR _Dir)
    {
        Arr = AllBlock[(int)_Type][(int)_Dir];
    }

    public void SetAccScreen()
    {
        for (int y = 0; y < 4; y++)
        {
            for (int x = 0; x < 4; x++)
            {
                if ("■" == Arr[y][x])
                {
                    AccScreen.SetBlock(Y+y-1, X+x, Arr[y][x]);
                }
            }
        }
    }

    public void Reset()
    {
        RandomBlockType();
        X = 0;
        Y = 1;
        SettingBlock(CurBlockType, CurDirType);
    }

    public bool DownCheck()
    {
        for(int y = 0; y<4; y++)
        {
            for (int x = 0; x < 4; x++)
            {
                if("■"==Arr[y][x])
                {
                    if (Y + y == AccScreen.Y || AccScreen.IsBlock(Y + y, X + x) == "■")
                    {
                        SetAccScreen();
                        Reset();
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public bool MoveCheck(bool _Right)
    {

        for (int y = 0; y < 4; y++)
        {
            for (int x = 0; x < 4; x++)
            {
                if ("■" == Arr[y][x])
                {
                    if (_Right)
                        if (X + x == AccScreen.X-1 || AccScreen.IsBlock(Y + y, X + x+1) == "■")
                        {
                            return true;
                        }
                    if (!_Right)
                        if (X + x == 0 || AccScreen.IsBlock(Y + y, X + x-1) == "■")
                        {
                            return true;
                        }
                }

            }
        }

        return false;
    }


    public void Down()
    {
        if(true==DownCheck())
        {
            return;
        }
        Y += 1;
    }

    public bool TurnCheck(AccScreen _Screen)
    {
        if (CurBlockType == BLOCKTYPE.BT_I)
        {
            for (int y = 0; y < 4; y++)
            {
                for (int x = 0; x < 4; x++)
                {
                    if ("■" == _Screen.IsBlock(Y + y, X + x)|| X + x == _Screen.X-1)
                    {
                        return true;
                    }
                }
            }
        }
        else
        {
            for (int y = 0; y < 3; y++)
            {
                for (int x = 0; x < 3; x++)
                {
                    if ("■" == _Screen.IsBlock(Y + y, X + x)|| X + x == _Screen.X-1)
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void Input(AccScreen _Screen)
    {
        

        if (Console.KeyAvailable==false)
        {
            if (Wait == 4)
            {
                Wait = 0;
                Y++;
            }

            if (false == DownCheck())
            {
                Wait++;
                return;
            }

            return;
        }

        //Console.CursorLeft = 10;

        switch(Console.ReadKey().Key)
        {
            case ConsoleKey.A:
                if(!MoveCheck(false))
                    X -= 1;
                break;
            case ConsoleKey.D:
                if (!MoveCheck(true))
                    X += 1;
                break;
            case ConsoleKey.S:
                Down();
                break;
            case ConsoleKey.Q: //turn L
                if (!TurnCheck(_Screen))
                {
                    if (CurDirType == 0)
                        CurDirType = BLOCKDIR.BD_MAX;
                    CurDirType--;
                    SettingBlock(CurBlockType, CurDirType);
                }
                break;
            case ConsoleKey.E: //turn R
                if (!TurnCheck(_Screen))
                {
                    CurDirType++;
                    if (CurDirType == BLOCKDIR.BD_MAX)
                        CurDirType = BLOCKDIR.BD_T;
                    SettingBlock(CurBlockType, CurDirType);
                }
                break;
            default:
                break;
        }
    }

    public void Move(AccScreen _Screen)
    {
        Input(_Screen);

        for (int y = 0; y < 4; y++)
        {
            for (int x = 0; x < 4; x++)
            {
                if (Arr[y][x] == "□")
                    continue;

                Screen.SetBlock(Y+y, X+x, Arr[y][x]);
            }
         }
        
        
    }

}
